# frozen_string_literal: true
module Irrgarten
  module Directions
    LEFT =:left
    RIGHT =:right
    UP =:up
    DOWN =:down
  end
end
