# frozen_string_literal: true
module Irrgarten
  module Orientation
    VERTICAL =:vertical
    HORIZONTAL =:horizontal
  end
end
