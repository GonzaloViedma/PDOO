# frozen_string_literal: true

class Irrgarten
end
