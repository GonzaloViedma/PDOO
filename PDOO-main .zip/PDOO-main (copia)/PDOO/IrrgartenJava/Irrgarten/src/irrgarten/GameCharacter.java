
package irrgarten;

public enum GameCharacter {
    PLAYER,
    MONSTER
}
