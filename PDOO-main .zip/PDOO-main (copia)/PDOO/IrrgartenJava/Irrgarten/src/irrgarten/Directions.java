
package irrgarten;


public enum Directions {
    LEFT,
    RIGHT,
    UP,
    DOWN
}
