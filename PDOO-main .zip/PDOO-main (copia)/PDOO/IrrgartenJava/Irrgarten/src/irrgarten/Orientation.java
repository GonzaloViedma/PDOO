
package irrgarten;

public enum Orientation {
    VERTICAL,
    HORIZONTAL
}
