
package irrgarten;

import java.util.ArrayList;

public class Irrgarten {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //ArrayList<Directions> validMoves = new ArrayList<>();
        //validMoves.add(Directions.RIGHT);
        //validMoves.add(Directions.DOWN);
        //Player p1 = new Player('1', 4.5f, 3.3f);
        //Directions d = p1.move(Directions.DOWN, validMoves);
        
        
        //Weapon w1 = new Weapon(2.0f,5);
        
        //p1.newWeapon(w1);
        
        //float suma = p1.sumWeapons();
        
       
    }
    
}
