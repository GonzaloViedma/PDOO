
/**
 *
 * @author gonzaalovd & carlitros_gamer20
 */
package irrgarten;


public class Monster {

    static private int INITIAL_HEALTH = 5;


   private String name;
   private float intelligence;
   private float strength;
   private float health = Monster.INITIAL_HEALTH;
   private int row = -1;
   private int col = -1;


   public Monster(String name, float intelligence, float strength){

       this.name = name;
       this.intelligence = intelligence;
       this.strength = strength;
   }

   public boolean dead(){
       return health == 0;
   }


    public float attack(){
        float damage = Dice.intensity(this.strength);
        return damage;
    }

    //public boolean defend(float recivedAttack){  
    //}
    public boolean defend(float recivedAttack){  
        boolean isDead = this.dead();
        
        if(!isDead){
            float defensiveEnergy = Dice.intensity(intelligence);
            if(defensiveEnergy < recivedAttack){
                this.gotWounded();
                isDead = this.dead();
            }
        }
        return isDead;
    }

    public void setPos(int row, int col){
        this.row = row;
        this.col = col;
    }

    public String toString(){

        String str;
        str ="M[" + this.name + "," + this.intelligence + "," + this.strength + "," + this.health + "]";
        return str;
    }

    private void gotWounded(){
        this.health--;
    }
}