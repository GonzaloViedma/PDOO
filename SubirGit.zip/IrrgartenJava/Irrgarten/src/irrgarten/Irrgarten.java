/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package irrgarten;
/**
 *
 * @author gonzaalovd & carlitros_gamer20
 */
public class Irrgarten {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*Weapon w1 = new Weapon(100,50);
        String info;
        
        info = w1.toString();
        System.out.println("Caracteristicas del arma:" + info);
        //Directions dir = Directions.DOWN;
        //System.out.println("La direccion es: " + dir);
        
        for (int i = 0; i<1000; i++){
            int n1 = Dice.randomPos(100);
            int n2 = Dice.randomPos(100);
            if(n1 == n2){
                System.out.println("Ha coincidido el numero :" + n1);
            }
            System.out.println("Dupla de numeros " + i + ": " + n1 + " y " + n2);    */
        
        Game juego = new Game(10);
        System.out.println(juego.showLab());
    }
    
}
